﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoCo
{
    class CsvWriter
    {
        public void Write(ToDoEntry newEntry, string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException();
            }
            else
            {
                StringBuilder entryBuilder = new StringBuilder();
                entryBuilder.Append(formatEntry(newEntry.Title, true));
                entryBuilder.Append(formatEntry(newEntry.Description));
                entryBuilder.Append(formatEntry(newEntry.IsDone.ToString().ToLower()));
                entryBuilder.Append(formatEntry(newEntry.ID.ToString(),false,true));
                File.AppendAllText(filePath, entryBuilder.ToString());
            }
        }

        private string formatEntry(string entry, bool isFirst = false, bool isLast = false)
        {
            if(isFirst)
            {
                return $"\nToDoEntry,\"{entry}\",";
            }
            else if(isLast)
            {
                return $"\"{entry}\"";
            }
            else
            {
                return $"\"{entry}\",";
            }
        }

    }
}
